## Summary
<!-- What does this PR do? -->

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Refactor / cleanup
- [ ] Dependency update
- [ ] Security fix

## Related Issues
Closes #

## Testing
<!-- How did you test this? -->

## Checklist
- [ ] Tests added / updated and passing (`pytest`)
- [ ] `black` and `ruff` pass with no errors
- [ ] `CHANGELOG.md` updated under `[Unreleased]`
- [ ] No secrets, credentials, or PII in the diff
- [ ] Docs updated if behaviour changed
