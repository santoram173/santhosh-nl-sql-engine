---
name: Feature Request
about: Suggest an improvement or new capability
labels: enhancement
---

## Problem / Motivation
<!-- What problem does this solve? Who benefits? -->

## Proposed Solution
<!-- How would you like it to work? -->

## Alternatives Considered
<!-- What other approaches did you think about? -->

## Additional Context
