# Santhosh — NL→SQL Assistant

> A production-grade Natural Language to SQL system that lets non-technical users query any PostgreSQL database using plain English — powered by Google Gemini, built with FastAPI, and designed with the same rigor as real-world LLM applications.

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110+-green.svg)](https://fastapi.tiangolo.com/)
[![Code Style: Black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

---

## The Problem

Data is locked inside databases that only engineers can query. Business analysts, product managers, and operations teams face three hard problems every day:

- They **can't write SQL** — so they wait on data teams for every insight
- **Data teams become bottlenecks** — hours or days to answer questions that should take seconds
- When they do get SQL, they **can't verify it** — no way to know if the query is right, safe, or returning complete data

Traditional NL-to-SQL tools fail because they treat the LLM as a blackbox oracle — no validation, no safety, no cost control. One wrong query can scan an entire production table or return misleading results with no warning.

**Santhosh solves all three.**

---

## Architecture

```
User (Plain English)
        │
        ▼
┌───────────────────┐
│  Intent Classifier │  → AGGREGATE_READ / FILTER / TIME_SERIES / MUTATE
└───────────────────┘
        │
        ▼
┌───────────────────┐
│  Schema Resolver   │  → Injects relevant table/column context into prompt
└───────────────────┘
        │
        ▼
┌───────────────────┐
│  Gemini SQL Gen    │  → Generates parameterized, safe SQL
└───────────────────┘
        │
        ▼
┌───────────────────┐
│  Safety Validator  │  → Blocks DDL/DML, estimates scan cost, checks indexes
└───────────────────┘
        │
        ▼
┌───────────────────┐
│  Query Executor    │  → Runs via psycopg2 with timeout + row limits
└───────────────────┘
        │
        ▼
┌───────────────────┐
│  Result Explainer  │  → LLM-generated plain English insight on results
└───────────────────┘
```

---

## Features

- **Intent Classification** — Queries are classified before SQL generation, enabling routing, logging, and safety decisions
- **Schema-Aware Prompting** — Only relevant table/column context is injected into each prompt (no full schema dumps)
- **Safety Guardrails** — Automatic blocking of `DROP`, `DELETE`, `UPDATE`, `INSERT`, `TRUNCATE`, and `ALTER` statements
- **Scan Cost Estimation** — `EXPLAIN` is run before execution; queries exceeding configurable row thresholds are rejected
- **Result Transparency** — Every query response includes the generated SQL, execution plan summary, row count, and LLM-generated explanation
- **Audit Logging** — Every query, generated SQL, safety decision, and result is logged for compliance
- **Cost Controls** — Per-user and per-hour Gemini API call limits configurable via environment variables
- **Read-Only Enforcement** — Database connection uses a dedicated read-only PostgreSQL role

---

## Tech Stack

| Layer | Technology |
|---|---|
| API | FastAPI 0.110+ |
| LLM | Google Gemini 1.5 Pro |
| Database | PostgreSQL 14+ via psycopg2 |
| Schema Introspection | SQLAlchemy Core |
| Auth | API key middleware (pluggable JWT) |
| Logging | structlog + JSON output |
| Testing | pytest + httpx |
| Containerization | Docker + docker-compose |

---

## Quick Start

### Prerequisites

- Python 3.11+
- PostgreSQL 14+
- Google Gemini API key

### Installation

```bash
git clone https://github.com/yourusername/santhosh-nl-sql.git
cd santhosh-nl-sql

python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

pip install -r requirements.txt
```

### Environment Setup

```bash
cp .env.example .env
```

Edit `.env`:

```env
# Google Gemini
GEMINI_API_KEY=your_gemini_api_key_here
GEMINI_MODEL=gemini-1.5-pro

# PostgreSQL (read-only user recommended)
DATABASE_URL=postgresql://readonly_user:password@localhost:5432/your_database

# Safety limits
MAX_SCAN_ROWS=500000
MAX_RESULT_ROWS=1000
QUERY_TIMEOUT_SECONDS=30

# Rate limiting
MAX_QUERIES_PER_HOUR=100
MAX_QUERIES_PER_USER_PER_HOUR=20

# API security
API_KEY_SECRET=your_secret_here
```

### Run

```bash
uvicorn app.main:app --reload --port 8000
```

Visit `http://localhost:8000/docs` for the interactive API documentation.

### Docker

```bash
docker-compose up --build
```

---

## API Reference

### `POST /api/v1/query`

Submit a natural language query.

**Request:**
```json
{
  "question": "Show me total revenue by product category for last quarter",
  "database": "analytics_db",
  "options": {
    "explain": true,
    "max_rows": 100
  }
}
```

**Response:**
```json
{
  "question": "Show me total revenue by product category for last quarter",
  "intent": "AGGREGATE_READ",
  "risk_level": "LOW",
  "sql": "SELECT p.category, SUM(o.amount) AS total_revenue ...",
  "execution": {
    "rows_returned": 4,
    "duration_ms": 14,
    "scan_estimate": 14200,
    "index_used": "idx_created_at"
  },
  "results": [...],
  "explanation": "Electronics leads at $284K — 45% above Software...",
  "query_id": "qry_01HXYZ..."
}
```

### `GET /api/v1/schema`

Returns the introspected schema for the connected database (tables, columns, types, sample values).

### `GET /api/v1/history`

Returns paginated query history for the authenticated user.

### `GET /api/v1/health`

Returns service health including DB connectivity and LLM reachability.

---

## Safety Model

Santhosh implements a layered safety approach:

1. **Intent gate** — `MUTATE` intent triggers immediate rejection with a user-friendly message
2. **SQL AST parse** — Generated SQL is parsed and validated before execution; any DDL or DML raises a `SafetyViolation`
3. **EXPLAIN pre-flight** — `EXPLAIN (FORMAT JSON)` is run first; if `rows` estimate exceeds `MAX_SCAN_ROWS`, the query is rejected
4. **Timeout** — All queries run with `statement_timeout` set at the connection level
5. **Row cap** — Results are always `LIMIT`-capped regardless of what the LLM generates
6. **Read-only role** — The database user has `SELECT` privileges only; no `WRITE` grants

---

## Project Structure

```
santhosh-nl-sql/
├── app/
│   ├── main.py                 # FastAPI app entry point
│   ├── routers/
│   │   ├── query.py            # /query endpoint
│   │   ├── schema.py           # /schema endpoint
│   │   └── health.py           # /health endpoint
│   ├── services/
│   │   ├── intent.py           # Intent classification
│   │   ├── schema_resolver.py  # Schema introspection & context building
│   │   ├── sql_generator.py    # Gemini prompt + SQL generation
│   │   ├── safety.py           # SQL validation & scan estimation
│   │   ├── executor.py         # psycopg2 query execution
│   │   └── explainer.py        # Result explanation via LLM
│   ├── models/
│   │   ├── request.py          # Pydantic request models
│   │   └── response.py         # Pydantic response models
│   ├── middleware/
│   │   ├── auth.py             # API key validation
│   │   ├── rate_limit.py       # Per-user rate limiting
│   │   └── audit.py            # Audit logging middleware
│   └── config.py               # Settings via pydantic-settings
├── tests/
│   ├── test_intent.py
│   ├── test_safety.py
│   ├── test_executor.py
│   └── test_api.py
├── docs/
│   ├── ARCHITECTURE.md
│   ├── DEPLOYMENT.md
│   └── CONTRIBUTING.md
├── legal/
│   ├── PRIVACY_POLICY.md
│   ├── TERMS_OF_USE.md
│   ├── SECURITY.md
│   └── DATA_PROCESSING_AGREEMENT.md
├── docker-compose.yml
├── Dockerfile
├── requirements.txt
├── .env.example
├── .gitignore
├── CHANGELOG.md
├── CODE_OF_CONDUCT.md
├── CONTRIBUTING.md
└── LICENSE
```

---

## Contributing

We welcome contributions! Please read [CONTRIBUTING.md](CONTRIBUTING.md) and our [Code of Conduct](CODE_OF_CONDUCT.md) before submitting a pull request.

---

## Security

For security vulnerabilities, please read [SECURITY.md](legal/SECURITY.md) and follow the responsible disclosure process. **Do not open public GitHub issues for security bugs.**

---

## Legal

- [Privacy Policy](legal/PRIVACY_POLICY.md)
- [Terms of Use](legal/TERMS_OF_USE.md)
- [Security Policy](legal/SECURITY.md)
- [Data Processing Agreement](legal/DATA_PROCESSING_AGREEMENT.md)

---

## License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for details.

---

## Acknowledgements

Built with [FastAPI](https://fastapi.tiangolo.com/), [Google Gemini](https://deepmind.google/technologies/gemini/), and [PostgreSQL](https://www.postgresql.org/). Inspired by production LLM application patterns from the enterprise AI community.
