# Security Policy

**Santhosh NL→SQL Assistant**

---

## Supported Versions

We actively maintain security fixes for the following versions:

| Version | Supported |
|---|---|
| `main` branch | ✅ Active |
| Latest release tag | ✅ Active |
| Releases > 6 months old | ⚠️ Best effort |
| Releases > 12 months old | ❌ Not supported |

---

## Reporting a Vulnerability

**Please do not report security vulnerabilities through public GitHub issues.**

Security bugs in Santhosh could enable:
- SQL injection via crafted natural language inputs
- Bypass of the read-only safety validator
- Exposure of database schema or credentials via error messages
- LLM prompt injection attacks
- Denial of service through expensive queries

### How to Report

1. **Email**: Open a [GitHub Security Advisory](https://docs.github.com/en/code-security/security-advisories/guidance-on-reporting-and-writing/privately-reporting-a-security-vulnerability) using the "Report a vulnerability" button on the Security tab of this repository.

2. **Alternatively**: Email the maintainer directly at the address listed in the GitHub profile (mark the email subject as `[SECURITY] Santhosh NL-SQL`).

### What to Include

Please include as much of the following as you can:

- A description of the vulnerability and its potential impact
- The component affected (intent classifier, safety validator, executor, API layer, etc.)
- Steps to reproduce the issue
- Proof-of-concept code or query (if applicable)
- Your suggested fix (if you have one)
- Whether you want public credit in the CVE/advisory

### Response Timeline

| Stage | Target Timeframe |
|---|---|
| Acknowledgement of report | Within 48 hours |
| Initial assessment & severity rating | Within 5 business days |
| Fix development begins | Within 10 business days for Critical/High |
| Coordinated disclosure | 90 days from report (or sooner if fix is ready) |

We follow a **90-day coordinated disclosure** policy. If we cannot resolve a critical issue within 90 days, we will communicate status and expected timeline before public disclosure.

---

## Security Architecture

Understanding Santhosh's security model helps you assess risk in your deployment.

### Defence Layers

**Layer 1 — Intent Classification**
Queries classified as `MUTATE` intent (inferred desire to modify data) are rejected before SQL generation begins.

**Layer 2 — SQL AST Validation**
All generated SQL is parsed into an abstract syntax tree before execution. Any statement containing `DROP`, `DELETE`, `UPDATE`, `INSERT`, `CREATE`, `ALTER`, `TRUNCATE`, `GRANT`, `REVOKE`, or multiple statements (`;` separated) raises a `SafetyViolation` and the query is rejected.

**Layer 3 — EXPLAIN Pre-flight**
`EXPLAIN (FORMAT JSON)` is executed before the actual query. If the estimated scan row count exceeds `MAX_SCAN_ROWS` (default: 500,000), the query is rejected with a cost estimate message.

**Layer 4 — Database-Level Enforcement**
The recommended deployment uses a PostgreSQL role with `SELECT`-only privileges. Even if all application-level safeguards fail, the database will reject `INSERT`/`UPDATE`/`DELETE` at the protocol level.

**Layer 5 — Query Timeout**
`statement_timeout` is set at the connection level (default: 30 seconds). Long-running queries are automatically cancelled by PostgreSQL.

**Layer 6 — Row Cap**
A `LIMIT` clause is appended to all queries (configurable via `MAX_RESULT_ROWS`). This prevents accidental full-table dumps via the API response.

### Known Limitations & Accepted Risks

| Risk | Mitigation | Residual Risk |
|---|---|---|
| Prompt injection via NL query | Input length limits, system prompt hardening | Medium — LLM behaviour cannot be fully controlled |
| Schema enumeration | Schema exposed in error messages is limited to relevant tables | Low — schema is not secret in most deployments |
| LLM hallucinating valid-but-wrong SQL | Safety validator catches structural issues; correctness validation is the user's responsibility | High — users must verify results |
| API key theft | Keys stored in env vars, not in code or logs | Low with correct deployment |
| DoS via expensive queries | EXPLAIN pre-flight + timeout + row cap | Low |

### What Santhosh Does NOT Protect Against

- Misuse by legitimate authenticated users (authorised users can query any table they have `SELECT` access to)
- Data-level access control (Santhosh does not implement row-level security — use PostgreSQL RLS for that)
- Confidentiality of query intent (all queries are logged)
- Prompt injection attacks that produce semantically incorrect but syntactically valid SELECT queries

---

## Secure Deployment Checklist

Before deploying Santhosh in production:

- [ ] Create a dedicated PostgreSQL read-only role with minimum required `SELECT` grants
- [ ] Rotate all API keys from the `.env.example` defaults
- [ ] Set `MAX_SCAN_ROWS` appropriate for your data volume
- [ ] Configure `QUERY_TIMEOUT_SECONDS` based on acceptable query latency
- [ ] Enable TLS on your Santhosh API endpoint
- [ ] Place Santhosh behind authentication (the built-in API key middleware or your own auth layer)
- [ ] Configure log retention and ensure logs do not capture query result rows
- [ ] Review Google Gemini's data handling policy for your data classification level
- [ ] Set up alerts on `SafetyViolation` log events
- [ ] Do not expose Santhosh directly to the public internet without rate limiting and authentication

---

## Security Hall of Fame

We gratefully acknowledge security researchers who have responsibly disclosed vulnerabilities:

*No disclosures yet — be the first!*

---

## Dependencies & CVE Monitoring

We use `pip-audit` in CI to scan for known CVEs in Python dependencies. If you discover a vulnerability in a dependency (not in Santhosh's own code), please report it upstream to that project and open a regular GitHub issue here so we can update the dependency.

---

*Last reviewed: April 24, 2026*
