# Terms of Use

**Santhosh NL→SQL Assistant**
**Last updated: April 24, 2026**
**Effective date: April 24, 2026**

---

## 1. Acceptance of Terms

By installing, deploying, accessing, or using the Santhosh NL→SQL Assistant software ("Santhosh", "the Software", "the Service"), you agree to be bound by these Terms of Use ("Terms").

If you are using Santhosh on behalf of an organisation, you represent that you have authority to bind that organisation to these Terms, and "you" refers to that organisation.

If you do not agree to these Terms, do not use the Software.

---

## 2. Open Source License

Santhosh is open-source software distributed under the **MIT License**. The full license text is available in [LICENSE](../LICENSE). These Terms of Use supplement, but do not replace, the MIT License terms. In the event of a conflict between these Terms and the MIT License, the MIT License governs with respect to software rights.

---

## 3. Description of Service

Santhosh is a software system that:

- Accepts natural language questions from users
- Classifies query intent
- Generates SQL queries using a large language model (Google Gemini)
- Validates and executes SQL against a connected PostgreSQL database
- Returns results with plain-English explanations

The Software is provided as a tool for **lawful data access** and **business intelligence** purposes only.

---

## 4. Permitted Use

You may use Santhosh to:

- Query databases you own or have lawful authorisation to access
- Build internal business intelligence tools for your organisation
- Develop and test integrations in non-production environments
- Contribute to the open-source project under the terms of [CONTRIBUTING.md](../CONTRIBUTING.md)

---

## 5. Prohibited Use

You must not use Santhosh to:

### 5.1 Unauthorised Access
- Query databases you do not own or have explicit authorisation to access
- Attempt to bypass, circumvent, or exploit the safety validation layer
- Use the Software to conduct, facilitate, or assist unauthorised computer access in violation of the Computer Fraud and Abuse Act (CFAA), the UK Computer Misuse Act, or equivalent laws in your jurisdiction

### 5.2 Harmful or Illegal Activity
- Process, exfiltrate, or expose personal data in violation of applicable privacy laws (GDPR, CCPA, HIPAA, etc.)
- Use the Software to discriminate against individuals based on protected characteristics
- Generate SQL designed to circumvent database access controls
- Use the Software in any way that violates applicable local, national, or international law

### 5.3 Abuse of Integrated Services
- Exceed or circumvent rate limits imposed by the Google Gemini API
- Use the Software to generate content that violates [Google's Generative AI Prohibited Use Policy](https://policies.google.com/terms/generative-ai/use-policy)
- Attempt to extract, reverse-engineer, or expose the underlying Gemini model weights or system prompts

### 5.4 Misrepresentation
- Represent Santhosh as a guaranteed-accurate or infallible SQL generation system
- Use Santhosh as the sole basis for financial, medical, legal, or safety-critical decisions without human review
- Claim official endorsement by Google or any other third party

---

## 6. AI-Generated SQL — Important Disclaimer

**Santhosh uses a large language model to generate SQL queries. LLM-generated SQL may be:**

- **Incorrect** — the model may misunderstand your intent, use wrong table/column names, or produce logically flawed queries
- **Incomplete** — results may be partial, especially for complex multi-table aggregations
- **Subtly wrong** — queries may return results that look correct but contain edge-case errors (e.g. off-by-one in date ranges, implicit type coercions)

**You must:**
- Review generated SQL before relying on results for important decisions
- Validate results against known ground truth for critical business queries
- Maintain human oversight of any automated pipelines built on top of Santhosh

The project maintainers accept no liability for decisions made based on incorrect query results. See Section 9 (Limitation of Liability).

---

## 7. Data Responsibilities

### 7.1 Your Responsibilities as Operator

If you deploy and operate Santhosh, you are responsible for:

- Ensuring your deployment complies with all applicable data protection laws
- Configuring appropriate database permissions (read-only role strongly recommended)
- Securing API keys and database credentials
- Informing end users of data processing practices (including the transmission of query text to Google Gemini)
- Maintaining audit logs as required by your regulatory obligations
- Implementing appropriate access controls for the Santhosh API

### 7.2 Sensitive Data

You should **not** use Santhosh to query or expose:

- Personal health information (PHI) subject to HIPAA without a Business Associate Agreement with Google and appropriate safeguards
- Payment card data subject to PCI-DSS
- EU personal data subject to GDPR without reviewing Google's data processing terms
- Classified or government-restricted information
- Trade secrets or confidential third-party data beyond your authorisation

---

## 8. Third-Party Services

Santhosh integrates with:

- **Google Gemini API** — subject to Google's [Terms of Service](https://ai.google.dev/gemini-api/terms)
- **PostgreSQL** — governed by your database provider's terms

You are responsible for compliance with all third-party terms applicable to your deployment.

---

## 9. Disclaimer of Warranties

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, ACCURACY, COMPLETENESS, OR NON-INFRINGEMENT.

THE PROJECT MAINTAINERS DO NOT WARRANT THAT:
- THE SOFTWARE WILL MEET YOUR REQUIREMENTS
- THE SOFTWARE WILL OPERATE ERROR-FREE OR WITHOUT INTERRUPTION
- SQL GENERATED BY THE SOFTWARE WILL BE CORRECT, COMPLETE, OR APPROPRIATE FOR YOUR USE CASE
- THE SOFTWARE WILL BE FREE FROM SECURITY VULNERABILITIES

---

## 10. Limitation of Liability

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL THE AUTHORS, CONTRIBUTORS, OR COPYRIGHT HOLDERS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING BUT NOT LIMITED TO PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; BUSINESS INTERRUPTION; OR DATA BREACH) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

---

## 11. Indemnification

You agree to indemnify, defend, and hold harmless the project maintainers and contributors from and against any claims, liabilities, damages, losses, and expenses (including reasonable legal fees) arising out of or in any way connected with:

- Your use of the Software in violation of these Terms
- Your violation of any applicable law or third-party rights
- Any data breach or unauthorised access resulting from your deployment's misconfiguration
- Any claim by a third party arising from your use of Santhosh

---

## 12. Modifications to the Terms

We reserve the right to modify these Terms at any time. Material changes will be communicated via GitHub release notes. Your continued use of the Software after changes are posted constitutes acceptance of the revised Terms.

---

## 13. Governing Law

These Terms are governed by and construed in accordance with the laws of the jurisdiction in which the primary project maintainer is located, without regard to conflict of law principles. For disputes arising in the European Union, mandatory consumer protection laws of your country of residence apply.

---

## 14. Severability

If any provision of these Terms is found to be unenforceable, the remaining provisions will continue in full force and effect.

---

## 15. Contact

Questions about these Terms? Open an issue at:
`https://github.com/yourusername/santhosh-nl-sql/issues`

---

*These Terms of Use are provided as a template for the Santhosh open-source project. They do not constitute legal advice. If you deploy this software commercially or in regulated industries, consult a qualified attorney.*
