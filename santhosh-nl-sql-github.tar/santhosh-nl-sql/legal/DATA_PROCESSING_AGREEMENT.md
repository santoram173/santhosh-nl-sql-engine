# Data Processing Agreement (Template)

**Santhosh NL→SQL Assistant**
**Version 1.0 — April 2026**

---

> **Note**: This document is a template Data Processing Agreement (DPA) for operators who deploy Santhosh to process personal data on behalf of their customers or users. It is intended to satisfy GDPR Article 28 requirements. You should have this document reviewed by a qualified legal professional before relying on it.

---

## Parties

This Data Processing Agreement ("DPA") is entered into between:

**Data Controller**: The entity or individual deploying and operating the Santhosh NL→SQL Assistant ("Controller", "you")

**Data Processor**: [Your organisation name] operating the Santhosh NL→SQL deployment ("Processor")

---

## 1. Definitions

In this DPA:

- **"Personal Data"** has the meaning given in applicable Data Protection Laws
- **"Processing"** has the meaning given in applicable Data Protection Laws
- **"Data Protection Laws"** means all applicable legislation relating to privacy and data protection, including the EU General Data Protection Regulation (GDPR) 2016/679, the UK GDPR, and the California Consumer Privacy Act (CCPA) as applicable
- **"Sub-processor"** means any third party engaged by the Processor to process Personal Data under this DPA
- **"Services"** means the Santhosh NL→SQL Assistant software and any associated services operated by the Processor

---

## 2. Scope and Nature of Processing

### 2.1 Subject Matter
The Processor shall process Personal Data only as necessary to provide the Services — specifically, to accept natural language queries, generate SQL, execute queries against the connected database, and return results.

### 2.2 Duration
Processing shall continue for the duration of the Controller's use of the Services, and for no longer than necessary for the purposes set out in this DPA.

### 2.3 Nature and Purpose of Processing

| Processing Activity | Purpose | Data Categories | Retention |
|---|---|---|---|
| Query logging | Audit, debugging, compliance | Query text, user ID, timestamps | 90 days (configurable) |
| Schema introspection | SQL generation context | Table/column names (metadata only) | In-memory only |
| LLM API transmission | SQL generation via Google Gemini | Query text, schema metadata | Per Google's retention policy |
| Rate limit tracking | Abuse prevention | User ID, request timestamps | 24 hours rolling |
| Error logging | Debugging | Query metadata, error traces (no row data) | 30 days |

### 2.4 Categories of Data Subjects
End users of the Controller's deployment who submit natural language queries.

### 2.5 Types of Personal Data
Query text submitted by end users may contain Personal Data at the discretion of those users. The Processor does not intentionally collect specific categories of Personal Data (special category data under GDPR Article 9) and the Controller should implement measures to prevent users from submitting such data.

---

## 3. Obligations of the Processor

The Processor shall:

**(a) Instructions** — Process Personal Data only on documented instructions from the Controller, including with regard to transfers of Personal Data to a third country or an international organisation, unless required to do so by applicable law.

**(b) Confidentiality** — Ensure that persons authorised to process Personal Data have committed to confidentiality or are under an appropriate statutory obligation of confidentiality.

**(c) Security** — Implement appropriate technical and organisational measures to ensure a level of security appropriate to the risk, including:
- Encryption of Personal Data in transit (TLS 1.2+)
- Access controls limiting who can access query logs
- Regular assessment of security measures
- Read-only database access model

**(d) Sub-processors** — Not engage another processor (Sub-processor) without prior written authorisation of the Controller, except as set out in Schedule 1 of this DPA.

**(e) Data Subject Rights** — Assist the Controller in responding to requests from data subjects exercising their rights under Data Protection Laws, taking into account the nature of the processing.

**(f) Security Assistance** — Assist the Controller in ensuring compliance with GDPR Articles 32–36 (security, breach notification, DPIA, prior consultation), taking into account the nature of the processing and information available to the Processor.

**(g) Deletion/Return** — At the choice of the Controller, delete or return all Personal Data after the end of the provision of Services, and delete existing copies unless required to store the data by applicable law.

**(h) Audit** — Make available all information necessary to demonstrate compliance with the obligations laid down in this Article and allow for and contribute to audits, including inspections, conducted by the Controller or another auditor mandated by the Controller.

---

## 4. Obligations of the Controller

The Controller shall:

**(a)** Ensure there is a lawful basis for processing Personal Data via the Services
**(b)** Provide accurate and complete instructions to the Processor
**(c)** Ensure data subjects have been informed about the use of the Services (including transmission to Google Gemini) in the Controller's own privacy notice
**(d)** Implement appropriate technical measures to prevent submission of special category data via the Services
**(e)** Maintain records of processing activities as required by GDPR Article 30
**(f)** Conduct a Data Protection Impact Assessment (DPIA) where required

---

## 5. Sub-processors

### 5.1 Authorised Sub-processors

The Controller hereby authorises the use of the following Sub-processors:

| Sub-processor | Location | Processing Activity | Legal Basis for Transfer |
|---|---|---|---|
| Google LLC (Gemini API) | United States | LLM inference — processes query text and schema metadata to generate SQL | Standard Contractual Clauses / Google's DPA |
| [Your PostgreSQL provider] | [Location] | Database hosting | [Your mechanism] |

### 5.2 Changes to Sub-processors
The Processor shall notify the Controller of any intended changes to Sub-processors, giving the Controller the opportunity to object to such changes within 14 days.

### 5.3 Google Gemini DPA
The Controller acknowledges that use of the Gemini API is subject to Google's own Data Processing Addendum, available at [https://ai.google.dev/gemini-api/terms](https://ai.google.dev/gemini-api/terms). The Controller is responsible for entering into appropriate terms with Google if required for their regulatory context.

---

## 6. International Data Transfers

Where the Processor transfers Personal Data to a Sub-processor outside the European Economic Area (EEA) or United Kingdom, the Processor shall ensure that such transfer is subject to appropriate safeguards in accordance with GDPR Chapter V, including:

- Standard Contractual Clauses (SCCs) adopted by the European Commission
- UK International Data Transfer Agreements (IDTAs) where applicable
- Adequacy decisions where available

---

## 7. Data Breach Notification

The Processor shall notify the Controller without undue delay, and in any event within **48 hours**, after becoming aware of a personal data breach involving Controller data. Notification shall include:

- Description of the nature of the breach including categories and approximate number of data subjects and records affected
- Contact details of the data protection officer or contact point
- Description of likely consequences of the breach
- Description of measures taken or proposed to address the breach

---

## 8. Data Protection Impact Assessments

The Processor shall provide reasonable assistance to the Controller in carrying out a Data Protection Impact Assessment (DPIA) where required under GDPR Article 35. Operators should consider whether a DPIA is required before deploying Santhosh to process employee or customer personal data at scale.

---

## 9. Deletion and Return of Data

Upon termination or expiry of the Services, or upon the Controller's request, the Processor shall:

- Within 30 days, delete or return all Personal Data processed under this DPA
- Provide written confirmation of deletion upon request
- Retain only such data as required by applicable law, for the minimum period required

---

## 10. Liability

Each party's liability under this DPA is subject to the limitations and exclusions set out in the Terms of Use and, where applicable, GDPR Article 82.

---

## 11. Governing Law

This DPA shall be governed by the laws of the jurisdiction applicable to the main agreement between the parties.

---

## Schedule 1 — Technical and Organisational Measures

The Processor implements the following measures:

### Access Control
- Database connections use a read-only PostgreSQL role
- API access requires authentication (API key or JWT)
- Query logs are access-controlled to authorised operations personnel

### Cryptography
- All API traffic uses TLS 1.2 or higher
- API keys and database credentials are stored in environment variables, not in code
- No Personal Data is stored at rest in the application layer beyond structured logs

### Availability
- Application health monitoring via `/health` endpoint
- Query timeout enforcement prevents runaway queries
- Rate limiting prevents abuse and DoS

### Data Minimisation
- Query result row data is never written to logs
- Only query metadata (question text, SQL, timing, row count) is retained
- Schema metadata is held in memory only, not persisted

### Incident Response
- Security incidents trigger automated alerts via structured log monitoring
- Incident response runbook is maintained in `docs/INCIDENT_RESPONSE.md`

---

*This DPA template is provided for informational purposes. It does not constitute legal advice. Operators deploying Santhosh to process EU/UK personal data should seek qualified legal counsel to ensure GDPR compliance.*
