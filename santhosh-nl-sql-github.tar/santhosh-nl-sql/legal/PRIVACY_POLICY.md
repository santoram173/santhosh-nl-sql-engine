# Privacy Policy

**Santhosh NL→SQL Assistant**
**Last updated: April 24, 2026**
**Effective date: April 24, 2026**

---

## 1. Introduction

This Privacy Policy describes how the Santhosh NL→SQL Assistant ("Santhosh", "we", "our", or "the Software") collects, uses, stores, and protects information when you use this open-source software.

Santhosh is open-source software distributed under the MIT License. If you self-host this software, **you** become the data controller for all data processed by your deployment. This policy applies to:

- The reference implementation and any deployment operated by the project maintainers
- Any deployment you operate using this codebase (you should adapt this policy accordingly)

---

## 2. Information We Process

### 2.1 Data You Provide

**Natural language queries**
When you submit a question in plain English, that text is processed to generate SQL. Queries may be logged for audit and debugging purposes.

**Database connection credentials**
Connection strings and credentials provided via environment variables are stored only in your server environment and are never transmitted to third-party services other than the target database.

**API keys**
Your Google Gemini API key is used solely to authenticate requests to the Gemini API on your behalf. It is stored in your server environment and never logged, transmitted to other services, or included in any analytics.

### 2.2 Data Processed Automatically

**Query logs**
Santhosh maintains structured logs of every query submitted, including: timestamp, user identifier (if auth is enabled), the natural language question, the generated SQL, intent classification result, safety check outcome, execution duration, and row count returned. Query logs do **not** include the actual data rows returned by your database.

**System telemetry**
No telemetry is sent to the project maintainers by default. All operational data stays within your deployment environment.

**Database schema metadata**
Santhosh introspects your database schema (table names, column names, data types) to provide context to the LLM. Schema metadata is held in memory during request processing and is not persisted to disk beyond your configured logging level.

### 2.3 Data We Do Not Collect

- The actual row data returned by database queries is never logged by Santhosh
- We do not collect IP addresses in the reference implementation by default (your reverse proxy may)
- We do not use tracking pixels, analytics beacons, or third-party analytics SDKs
- We do not sell, rent, or share any data with third parties for commercial purposes

---

## 3. How We Use Information

| Purpose | Legal Basis | Data Used |
|---|---|---|
| Generating SQL from natural language | Performance of service | NL query text, schema metadata |
| Safety validation | Legitimate interest (preventing harm) | Generated SQL |
| Audit logging | Legitimate interest / legal compliance | Query metadata (not row data) |
| Debugging and error handling | Legitimate interest | Query metadata, error traces |
| Rate limiting | Legitimate interest | User identifier, request timestamps |

---

## 4. Third-Party Services

### 4.1 Google Gemini API

Santhosh sends natural language queries and database schema context to the **Google Gemini API** for SQL generation and result explanation. This means:

- Your query text and relevant schema metadata (table/column names) are transmitted to Google's infrastructure
- Google's [Privacy Policy](https://policies.google.com/privacy) and [Gemini API Terms of Service](https://ai.google.dev/gemini-api/terms) apply to this data
- You should review Google's data retention policies for API usage before deploying Santhosh with sensitive data
- **Do not submit queries containing personally identifiable information (PII), protected health information (PHI), or sensitive financial data** unless you have verified Google's data handling meets your compliance requirements

### 4.2 PostgreSQL

Your PostgreSQL database is accessed using credentials you provide. Santhosh only reads data (SELECT queries only in the safety model). Your database provider's privacy and security policies govern data stored there.

---

## 5. Data Retention

**Query logs** are retained according to your deployment configuration. The default is 90 days. You can configure this via the `LOG_RETENTION_DAYS` environment variable.

**In-memory schema cache** is discarded when the server process terminates. It is not persisted to disk.

**Session data** is not retained between requests in the default stateless configuration.

---

## 6. Data Security

We implement the following security measures:

- **Read-only database access** — Santhosh connects to PostgreSQL using a read-only role with SELECT privileges only
- **SQL injection prevention** — All generated SQL is parsed and validated before execution; parameterized queries are used where values are injected
- **Secret management** — Credentials are loaded from environment variables, never hardcoded or logged
- **Transport encryption** — All API communication uses TLS 1.2+
- **Input sanitisation** — Natural language input is length-limited and sanitised before processing

Despite these measures, no system is 100% secure. You are responsible for securing your own deployment, including network access controls, database permissions, and API key rotation.

---

## 7. Your Rights (GDPR / CCPA)

If you are in the European Economic Area, UK, or California, you may have the following rights regarding personal data processed by Santhosh:

- **Access** — Request a copy of data held about you
- **Rectification** — Request correction of inaccurate data
- **Erasure** — Request deletion of your data ("right to be forgotten")
- **Portability** — Request your data in a machine-readable format
- **Objection** — Object to certain types of processing
- **Restriction** — Request that processing be restricted while a dispute is resolved

To exercise these rights, open an issue on the GitHub repository or contact the deployment operator directly.

Note: For self-hosted deployments, the operator of that deployment is the data controller and is responsible for fulfilling these requests.

---

## 8. Children's Privacy

Santhosh is not directed at children under the age of 16. We do not knowingly process personal data from children. If you become aware that a child has provided personal data, please contact the deployment operator.

---

## 9. International Data Transfers

If you use the Google Gemini API, your query data may be transferred to and processed in the United States or other countries where Google operates data centres. By using Santhosh with the Gemini integration, you consent to this transfer.

For EEA/UK deployments, ensure you have appropriate transfer mechanisms in place (e.g. Standard Contractual Clauses with Google).

---

## 10. Changes to This Policy

We may update this Privacy Policy from time to time. Material changes will be noted in the [CHANGELOG.md](../CHANGELOG.md) and communicated via a GitHub release. The "Last updated" date at the top of this document will always reflect the most recent revision.

---

## 11. Contact

For privacy-related questions about this open-source project, open an issue at:
`https://github.com/yourusername/santhosh-nl-sql/issues`

For self-hosted deployments, contact the operator of that deployment directly.

---

*This Privacy Policy was written for the Santhosh NL→SQL open-source project. It is provided as a template and starting point. If you deploy this software commercially or process regulated data (HIPAA, PCI-DSS, etc.), you should have this policy reviewed by a qualified legal professional.*
