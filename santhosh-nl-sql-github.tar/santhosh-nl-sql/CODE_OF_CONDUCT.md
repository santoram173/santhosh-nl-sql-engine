# Code of Conduct

## Our Pledge

We as members, contributors, and maintainers pledge to make participation in Santhosh a harassment-free experience for everyone, regardless of age, body size, visible or invisible disability, ethnicity, sex characteristics, gender identity and expression, level of experience, education, socio-economic status, nationality, personal appearance, race, caste, colour, religion, or sexual identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming, diverse, inclusive, and healthy community.

---

## Our Standards

**Positive behaviour includes:**
- Using welcoming and inclusive language
- Being respectful of differing viewpoints and experiences
- Gracefully accepting constructive criticism
- Focusing on what is best for the community
- Showing empathy towards other community members

**Unacceptable behaviour includes:**
- The use of sexualised language or imagery, and sexual attention or advances of any kind
- Trolling, insulting or derogatory comments, and personal or political attacks
- Public or private harassment
- Publishing others' private information (physical or email address) without explicit permission
- Other conduct which could reasonably be considered inappropriate in a professional setting

---

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behaviour may be reported by opening a GitHub issue marked `[conduct]` or contacting the maintainer directly. All complaints will be reviewed and investigated promptly and fairly. Maintainers are obligated to respect the privacy and security of the reporter.

---

## Enforcement Guidelines

| Violation | Consequence |
|---|---|
| Minor, first offence | Private written warning |
| Repeated or moderate | Temporary ban from interactions |
| Severe or sustained | Permanent ban |

---

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org/), version 2.1.
