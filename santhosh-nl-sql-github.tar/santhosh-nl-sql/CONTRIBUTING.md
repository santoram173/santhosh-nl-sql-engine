# Contributing to Santhosh NL→SQL

Thank you for your interest in contributing! This document explains how to get involved.

---

## Code of Conduct

By participating, you agree to uphold our [Code of Conduct](CODE_OF_CONDUCT.md).

---

## Ways to Contribute

- **Bug reports** — Open an issue with steps to reproduce
- **Feature requests** — Open an issue describing the use case
- **Pull requests** — See the workflow below
- **Documentation** — Fix typos, clarify explanations, add examples
- **Security** — See [SECURITY.md](legal/SECURITY.md) for responsible disclosure

---

## Development Setup

```bash
git clone https://github.com/yourusername/santhosh-nl-sql.git
cd santhosh-nl-sql
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pip install -r requirements-dev.txt
cp .env.example .env  # fill in your keys
```

Run tests:
```bash
pytest tests/ -v
```

Run linter:
```bash
black app/ tests/
ruff app/ tests/
```

---

## Pull Request Workflow

1. Fork the repo and create a branch: `git checkout -b feat/your-feature`
2. Make your changes with tests
3. Ensure `pytest` passes and `black`/`ruff` report no issues
4. Open a PR against `main` with a clear description
5. Link any related issues using `Closes #123`

### PR Checklist

- [ ] Tests added or updated
- [ ] `black` and `ruff` pass
- [ ] Docstrings updated for changed functions
- [ ] `CHANGELOG.md` entry added under `[Unreleased]`
- [ ] No secrets, credentials, or personal data in the diff

---

## Commit Style

Use [Conventional Commits](https://www.conventionalcommits.org/):

```
feat: add time-series intent classifier
fix: correct scan estimate for CTEs
docs: expand deployment guide
test: add safety validator edge cases
chore: bump gemini-sdk to 1.4.0
```

---

## Branching

| Branch | Purpose |
|---|---|
| `main` | Stable, always deployable |
| `feat/*` | New features |
| `fix/*` | Bug fixes |
| `docs/*` | Documentation only |
| `chore/*` | Maintenance, deps |

---

## Questions?

Open a [Discussion](https://github.com/yourusername/santhosh-nl-sql/discussions) — not an issue — for general questions about usage or architecture.
