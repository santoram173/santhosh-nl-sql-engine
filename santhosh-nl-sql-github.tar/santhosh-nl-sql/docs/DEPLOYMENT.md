# Deployment Guide

**Santhosh NL→SQL — Production Deployment Reference**

---

## Prerequisites

| Requirement | Minimum | Recommended |
|---|---|---|
| Python | 3.11 | 3.12 |
| PostgreSQL | 14 | 15+ |
| RAM | 512 MB | 2 GB |
| CPU | 1 vCPU | 2 vCPU |
| OS | Ubuntu 22.04 / Debian 12 | Same |

---

## 1. PostgreSQL Setup

Create a dedicated read-only role. Never use a superuser or write-capable account.

```sql
-- Create read-only role
CREATE ROLE santhosh_readonly WITH LOGIN PASSWORD 'strong_password_here';

-- Grant connection
GRANT CONNECT ON DATABASE your_database TO santhosh_readonly;

-- Grant usage on schema
GRANT USAGE ON SCHEMA public TO santhosh_readonly;

-- Grant select on all current tables
GRANT SELECT ON ALL TABLES IN SCHEMA public TO santhosh_readonly;

-- Grant select on future tables
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT SELECT ON TABLES TO santhosh_readonly;
```

Update `.env`:
```env
DATABASE_URL=postgresql://santhosh_readonly:strong_password_here@localhost:5432/your_database
```

---

## 2. Docker Deployment (Recommended)

```bash
git clone https://github.com/yourusername/santhosh-nl-sql.git
cd santhosh-nl-sql
cp .env.example .env
# Edit .env with your values
docker-compose up --build -d
```

`docker-compose.yml` starts:
- `santhosh-api` — FastAPI app on port 8000
- `nginx` — Reverse proxy with TLS termination (bring your own certs)

Check health:
```bash
curl http://localhost:8000/api/v1/health
```

---

## 3. Bare Metal / VM Deployment

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Run with gunicorn for production
pip install gunicorn
gunicorn app.main:app \
  --workers 4 \
  --worker-class uvicorn.workers.UvicornWorker \
  --bind 0.0.0.0:8000 \
  --timeout 60 \
  --access-logfile - \
  --error-logfile -
```

### systemd Service

```ini
# /etc/systemd/system/santhosh.service
[Unit]
Description=Santhosh NL→SQL API
After=network.target

[Service]
User=santhosh
WorkingDirectory=/opt/santhosh-nl-sql
EnvironmentFile=/opt/santhosh-nl-sql/.env
ExecStart=/opt/santhosh-nl-sql/venv/bin/gunicorn app.main:app \
  --workers 4 \
  --worker-class uvicorn.workers.UvicornWorker \
  --bind 0.0.0.0:8000
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
systemctl enable santhosh
systemctl start santhosh
```

---

## 4. TLS / HTTPS

Always terminate TLS before the Santhosh API. Use nginx or Caddy:

**Caddy (simplest):**
```
api.yourdomain.com {
  reverse_proxy localhost:8000
}
```

Caddy handles Let's Encrypt automatically.

---

## 5. Security Hardening Checklist

- [ ] PostgreSQL role is read-only (verify with `\dp` in psql)
- [ ] `API_KEY_SECRET` is a random 32+ character string (not the example value)
- [ ] `GEMINI_API_KEY` has appropriate restrictions in Google Cloud Console
- [ ] `.env` file permissions: `chmod 600 .env`
- [ ] TLS enabled on all external endpoints
- [ ] Firewall blocks direct access to port 8000 (only nginx/Caddy exposed)
- [ ] `MAX_SCAN_ROWS` set to a value appropriate for your data volume
- [ ] Audit logs shipped to external storage (CloudWatch, Datadog, etc.)
- [ ] Set up alerting on `safety_passed: false` log events

---

## 6. Environment Variables Reference

| Variable | Default | Description |
|---|---|---|
| `GEMINI_API_KEY` | required | Google Gemini API key |
| `GEMINI_MODEL` | `gemini-1.5-pro` | Gemini model identifier |
| `DATABASE_URL` | required | PostgreSQL connection string |
| `MAX_SCAN_ROWS` | `500000` | EXPLAIN row estimate limit |
| `MAX_RESULT_ROWS` | `1000` | Max rows returned per query |
| `QUERY_TIMEOUT_SECONDS` | `30` | PostgreSQL statement_timeout |
| `MAX_QUERIES_PER_HOUR` | `100` | Global rate limit |
| `MAX_QUERIES_PER_USER_PER_HOUR` | `20` | Per-user rate limit |
| `API_KEY_SECRET` | required | Secret for API key validation |
| `LOG_LEVEL` | `INFO` | Logging verbosity |
| `LOG_RETENTION_DAYS` | `90` | Audit log retention |
| `LOG_QUERY_TEXT` | `true` | Set `false` to omit NL query from logs |
| `APP_ENV` | `development` | `development` or `production` |
| `APP_PORT` | `8000` | Port to bind |

---

## 7. Monitoring

Santhosh emits structured JSON logs. Key fields to alert on:

| Log Field | Alert Condition | Meaning |
|---|---|---|
| `safety_passed: false` | Any occurrence | Query blocked by safety validator |
| `error` non-null | > 1% of requests | Application errors |
| `duration_ms` | > 10000 | Slow queries |
| `scan_estimate` | > 400000 | Queries approaching scan limit |

Ship logs to your preferred aggregator (Datadog, Grafana Loki, CloudWatch).

---

## 8. Upgrading

```bash
git pull origin main
pip install -r requirements.txt
systemctl restart santhosh  # or: docker-compose up --build -d
```

Check [CHANGELOG.md](../CHANGELOG.md) for breaking changes before upgrading.
