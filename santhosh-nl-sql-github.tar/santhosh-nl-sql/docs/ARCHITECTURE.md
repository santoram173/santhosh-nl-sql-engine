# Architecture

**Santhosh NL→SQL — System Design Reference**

---

## Overview

Santhosh implements a **6-stage pipeline** between a user's plain English question and a verified SQL result. Each stage is independently testable and can be replaced or extended without touching adjacent stages.

```
NL Question
    │
    ▼
┌─────────────────────┐
│ 1. Intent Classifier │  Gemini zero-shot → AGGREGATE_READ | FILTER_READ |
│                      │  TIME_SERIES_READ | MUTATE | UNKNOWN
└─────────────────────┘
    │ MUTATE → reject immediately
    ▼
┌─────────────────────┐
│ 2. Schema Resolver   │  PostgreSQL information_schema → relevant tables +
│                      │  columns injected as structured context
└─────────────────────┘
    │
    ▼
┌─────────────────────┐
│ 3. SQL Generator     │  Gemini with schema context → raw SQL string
│                      │  Prompt enforces: SELECT only, no semicolons in body,
│                      │  use parameterised values, add LIMIT
└─────────────────────┘
    │
    ▼
┌─────────────────────┐
│ 4. Safety Validator  │  AST parse → DDL/DML check
│                      │  EXPLAIN pre-flight → scan estimate
│                      │  Rejects if cost > MAX_SCAN_ROWS
└─────────────────────┘
    │
    ▼
┌─────────────────────┐
│ 5. Query Executor    │  psycopg2 read-only connection
│                      │  statement_timeout enforced at connection level
│                      │  Results capped at MAX_RESULT_ROWS
└─────────────────────┘
    │
    ▼
┌─────────────────────┐
│ 6. Result Explainer  │  Gemini with result metadata → plain English insight
│                      │  (not the raw rows — just stats and patterns)
└─────────────────────┘
    │
    ▼
JSON Response to client
```

---

## Request Lifecycle

```
Client → FastAPI router
            │
            ├─ Auth middleware (API key / JWT)
            ├─ Rate limit middleware
            ├─ Audit log middleware (request)
            │
            ▼
        QueryService.run(question)
            │
            ├─ IntentClassifier.classify(question) → IntentResult
            ├─ SchemaResolver.resolve(intent, question) → SchemaContext
            ├─ SQLGenerator.generate(question, schema_ctx) → raw_sql
            ├─ SafetyValidator.validate(raw_sql) → SafetyResult
            ├─ QueryExecutor.execute(safe_sql) → QueryResult
            └─ ResultExplainer.explain(result_metadata) → insight_text
            │
            ├─ Audit log middleware (response + metadata)
            │
            ▼
        QueryResponse (JSON)
```

---

## Key Design Decisions

### Why classify intent before generating SQL?

Intent classification runs a lightweight Gemini call with a small prompt before the expensive schema-aware SQL generation. Benefits:
- MUTATE queries are rejected in ~200ms with no schema lookup or SQL generation
- Intent label enables routing (future: send complex aggregations to a specialist prompt)
- Intent is logged separately, enabling analytics on what users are actually trying to do

### Why EXPLAIN before execute?

Running `EXPLAIN` costs milliseconds but catches queries that would scan millions of rows. In production databases, a single runaway query from a well-meaning analyst can tank performance for everyone. The pre-flight cost estimate is a hard gate, not a warning.

### Why a read-only PostgreSQL role?

Defence in depth. Even if every application-layer safety check fails (prompt injection produces a `DELETE`, AST parser has a bug, etc.), the database will reject the query at the protocol level. Application-layer security should never be the only line of defence for a database.

### Why not stream results?

The current design returns results as a complete JSON object. This simplifies the safety model (we can apply LIMIT before returning) and makes audit logging straightforward. Streaming can be added later as an opt-in for large result sets.

---

## Component Boundaries

```
app/
├── routers/        # HTTP interface only — no business logic
├── services/       # All business logic — no HTTP concerns
│   ├── intent.py          # Pure function: str → IntentResult
│   ├── schema_resolver.py # DB read: question + intent → SchemaContext
│   ├── sql_generator.py   # LLM call: question + schema → SQL string
│   ├── safety.py          # Pure + DB read: SQL → SafetyResult
│   ├── executor.py        # DB read: SQL → rows + metadata
│   └── explainer.py       # LLM call: metadata → insight string
├── models/         # Pydantic schemas — shared across layers
├── middleware/     # Cross-cutting: auth, rate limit, audit
└── config.py       # All configuration in one place
```

Each service has a single responsibility and explicit inputs/outputs. This makes unit testing straightforward: mock the LLM and DB calls, test the logic.

---

## Observability

Every request produces a structured JSON log event containing:

```json
{
  "timestamp": "2026-04-24T10:23:01Z",
  "query_id": "qry_01HXYZ...",
  "user_id": "usr_abc",
  "intent": "AGGREGATE_READ",
  "risk_level": "LOW",
  "sql_generated": true,
  "safety_passed": true,
  "scan_estimate": 14200,
  "rows_returned": 4,
  "duration_ms": 847,
  "gemini_tokens_used": 1203,
  "error": null
}
```

Row data is never logged. Query text is logged (configure `LOG_QUERY_TEXT=false` to disable for privacy-sensitive deployments).

---

## Scaling Considerations

- **Stateless API** — All state is in PostgreSQL and logs. Scale horizontally behind a load balancer.
- **Schema cache** — Add Redis caching for `SchemaResolver` to avoid repeated `information_schema` queries under load.
- **Gemini latency** — The two Gemini calls (intent + generation) are the dominant latency source (~1–3s). Consider parallelising intent classification and schema resolution.
- **Connection pooling** — Use `asyncpg` with a connection pool for high-throughput deployments. The reference implementation uses synchronous `psycopg2` for simplicity.
