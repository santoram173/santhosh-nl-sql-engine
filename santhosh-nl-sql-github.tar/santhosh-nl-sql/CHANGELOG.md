# Changelog

All notable changes to Santhosh NL→SQL will be documented here.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
This project adheres to [Semantic Versioning](https://semver.org/).

---

## [Unreleased]

### Added
- Initial public release

---

## [1.0.0] — 2026-04-24

### Added
- Natural language to SQL pipeline powered by Google Gemini 1.5 Pro
- Intent classification (AGGREGATE_READ, TIME_SERIES_READ, FILTER_READ, MUTATE)
- Schema-aware prompting with PostgreSQL introspection
- 6-layer safety validation model (intent gate, AST parse, EXPLAIN pre-flight, DB role, timeout, row cap)
- FastAPI REST API with `/query`, `/schema`, `/history`, `/health` endpoints
- Structured audit logging via structlog
- Per-user rate limiting middleware
- API key authentication middleware
- Docker + docker-compose support
- Full legal & privacy documentation (Privacy Policy, Terms of Use, Security Policy, DPA)
- MIT License

[Unreleased]: https://github.com/yourusername/santhosh-nl-sql/compare/v1.0.0...HEAD
[1.0.0]: https://github.com/yourusername/santhosh-nl-sql/releases/tag/v1.0.0
